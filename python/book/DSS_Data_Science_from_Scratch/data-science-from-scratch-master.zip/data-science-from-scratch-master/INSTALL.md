# How to Install Python

TODO: how to install python
